package com.poly.testmaven;

/**
 * Hello world!
 *
 */
public class App 
{
	public boolean isEventNumber(int input) {
		if(input%2 == 0 ) {
			return true;
		}else {
			return false; 
		}
	}
	public static void main(String[] args) {
		System.out.print("Hello world!");
	}
}
